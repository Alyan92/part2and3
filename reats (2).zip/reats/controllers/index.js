//this file is reposnsible for packaging and exporting all resource
//controllers appropriately

//imports
const propertyController = require('./propertyController')

//exports
module.exports = {
    properties: propertyController
}